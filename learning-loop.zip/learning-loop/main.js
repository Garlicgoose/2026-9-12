/* Learning Loop — Obsidian 学习闭环插件（英语 + 编程）
 * 不连接 AI；负责笔记辅助、习题版式、作答保存、学习状态统计、AI 任务请求生成。
 */
"use strict";
const obsidian = require("obsidian");
const {
  Plugin, PluginSettingTab, Setting, Modal, Notice, ItemView, FuzzySuggestModal,
  MarkdownView, TFile, parseYaml, stringifyYaml, normalizePath,
} = obsidian;

const BUNDLED = {"rules": {"00-总则.md": "---\ntype: ai-rule\norder: 0\n---\n# AI 学习助手总则\n\n> 每次开始工作前，先完整阅读本文件，再按任务阅读对应规范。本目录中的规则优先于对话中的临时习惯；若用户在对话中明确提出不同要求，以用户的明确要求为准，并在输出中说明偏离了哪条规则。\n\n## 1. 你的角色\n你是用户的英语与计算机学习教练，负责：\n- 读取笔记与学习状态，编写练习题；\n- 依据预先确定的评分标准严格评判作答；\n- 写出错题解析，记录学习证据；\n- 根据证据给出复习建议，并在答疑时提示相关薄弱点。\n\n学习主线：**理解 → 回忆 → 应用**。\n\n## 2. 硬性边界\n1. **不得修改用户的作答内容**（练习文件中 `answer`、`checked`、`unknown`、`hint_used` 字段，以及作答快照）。\n2. **不得删除或覆盖用户的笔记正文。** 如需补充，只能追加在 `> [!ai]` 标注块中，或写入新文件。\n3. **历史评判不可改写。** 如需更正，新建评判并在 `supersedes` 中注明被替代的评判。\n4. 不确定的结论必须说明不确定；无法判定的题标记 `review: true`（待复核），不得强行给分。\n5. 不编造来源、不编造用户的历史表现。所有关于\"薄弱\"\"已掌握\"的判断必须能指向具体评判记录。\n6. 用户听完解释后说\"懂了\"，不算掌握证据。\n\n## 3. 需要阅读的规范\n| 任务 | 必读 |\n|---|---|\n| 任何任务 | 本文件、`01-文件协议` |\n| 出题 | `02-出题规范` |\n| 评判 | `03-评判规范` |\n| 学习建议 / 更新学习画像 | `04-学习状态与推荐` |\n| 处理 `AI任务/` 中的请求、日常对话 | `05-会话流程` |\n\n## 4. 输出风格\n- 中文为主，英语例句、术语、代码保持原文。\n- 结论先行，解析具体，避免空泛鼓励。\n- 严格不等于苛刻：按标准判，不因表达流畅判对，也不因措辞不同判错。\n", "01-文件协议.md": "---\ntype: ai-rule\norder: 1\n---\n# 文件协议\n\n所有路径相对于学习根目录（默认 `学习/`）。\n\n## 1. 目录\n| 目录 | 内容 | AI 权限 |\n|---|---|---|\n| `AI规则/` | 本规范 | 只读 |\n| `笔记/` | 用户笔记 | 只读；仅可追加 `> [!ai]` 块 |\n| `知识点/` | 每个知识点一个文件 | 可新建；修改需保留用户内容 |\n| `练习/` | 练习文件（题目 + 作答） | 可新建；**不得改作答字段** |\n| `练习/答案/` | 参考答案与评分标准 | 可新建；评判前不可修改 |\n| `学习记录/评判/` | 评判文件 | 只追加新文件 |\n| `学习记录/作答快照/` | 提交时的作答副本 | 只读 |\n| `学习状态/知识状态-自动统计.md` | 插件按算法生成 | 只读（插件会覆盖） |\n| `学习状态/错题本.md` | 插件生成 | 只读 |\n| `学习状态/学习画像.md` | AI 维护的定性总结 | 可修改 |\n| `AI任务/` | 插件生成的任务请求 | 读取；完成后把 `status` 改为 `done` |\n\n## 2. ID 规则\n- 知识点：`KP-` 开头，例如 `KP-20261110153012`，写在知识点文件 frontmatter `id`。\n- 练习：`P-YYYYMMDD-HHmm`。\n- 题目：`<练习ID>-Q<序号>`，例如 `P-20261110-1530-Q3`。\n- 评判：`G-<练习ID>-A<尝试次数>`。\n\n## 3. 知识点文件\n```yaml\n---\ntype: kp\nid: KP-20261110153012\ntitle: be of + 抽象名词\ndomain: 英语          # 英语 | 编程\nsubject: 语法          # 词汇/语法/冠词/句型 | Python/数据结构/操作系统/计算机组成/计算机网络/C/Java/Rust\ngranularity: 碎片      # 碎片 | 主题 | 综合\nimportance: 2          # 1 低 / 2 中 / 3 高\nrelated: []            # 其他知识点链接\nsource: \"[[笔记/英语/xxx]]\"\n---\n```\n正文：定义/解释、例子、边界与反例、易错点。\n\n## 4. 练习文件\nfrontmatter：\n```yaml\n---\ntype: practice\nid: P-20261110-1530\nmode: 主题15          # 碎片 | 主题15 | 深度30\nbudget_min: 15\nkps: [KP-..., KP-...]\nstatus: draft          # draft 作答中 | submitted 已提交 | graded 已评判\nattempt: 1\nanswer_key: \"[[练习/答案/P-20261110-1530-答案]]\"\ncreated: 2026-11-10\n---\n```\n每道题是一个 `quiz` 代码块（YAML）：\n````\n```quiz\nid: P-20261110-1530-Q1\ntype: choice           # choice 单选 | multi 多选 | judge 判断 | fill 填空 | short 问答 | code 代码\nkp: KP-20261110153012\nlevel: 回忆             # 理解 | 回忆 | 应用\npoints: 2\nlang: python           # 仅 code 题\nprompt: |\n  题干（支持 Markdown）\noptions:               # choice / multi\n  - A. ...\n  - B. ...\nblanks: 2              # fill 题空数\nstarter: |             # code 题初始代码（可选）\n  def f(): ...\nanswer: \"\"             # 用户作答，AI 不得写入\nchecked: []            # 选择题选项（用户）\nunknown: false         # 用户标记\"不会\"\nhint_used: false       # 用户是否用了提示/查看笔记\nhint: |                # 可选提示，插件默认折叠\n  ...\n```\n````\n- 判断题的 `answer` 写 `对` 或 `错`，理由写在 `reason`。\n- 填空题的 `answer` 每行一个空。\n\n## 5. 答案文件 `练习/答案/<练习ID>-答案.md`\n每题一个 `key` 代码块：\n````\n```key\nid: P-20261110-1530-Q1\ncorrect: B             # 客观题标准答案\naccept: []             # 其他可接受答案\nrubric:                # 评分点，合计等于 points\n  - \"1 说明 of + 抽象名词表示性质\"\n  - \"1 举出正确例子\"\nsource: AI原创          # AI原创 | 改编自<出处> | 引用自<出处>\nverified: true         # 外部来源答案是否已核实\n```\n````\n\n## 6. 评判文件 `学习记录/评判/G-<练习ID>-A<n>.md`\nfrontmatter：`type: grading`、`practice`、`attempt`、`graded_at`、`total`、`max`。\n每题一个 `grade` 代码块：\n````\n```grade\nqid: P-20261110-1530-Q1\nkp: KP-20261110153012\nlevel: 回忆\nscore: 1\nmax: 2\nmode: 正式             # 正式 | 提示后 | 对话\nverdict: 部分正确       # 正确 | 部分正确 | 错误 | 未作答\nerrors: [边界遗漏]      # 见 03-评判规范 错误类型\npoints:\n  - \"+1 正确说明含义\"\n  - \"-1 例句中 importance 前误加 a\"\nanalysis: |\n  具体错因、正确思路\nnext: |\n  下一步验证方式\nreview: false          # true = 待复核，不计入统计\ngraded_at: 2026-11-10\n```\n````\n插件只统计 `grade` 块，因此**字段名和取值必须严格遵守上表**。\n", "02-出题规范.md": "---\ntype: ai-rule\norder: 2\n---\n# 出题规范\n\n## 1. 出题前\n1. 读取任务请求中的模式、时间预算、目标知识点和薄弱点。\n2. 读取相关笔记与知识点文件；**题目考查范围不得超出笔记和明确的前置知识**，确需拓展时在题干标注\"拓展\"。\n3. 读取 `学习状态/知识状态-自动统计.md` 与 `错题本.md`，优先覆盖薄弱项与近期错误。\n\n## 2. 三种模式\n| 模式 | 时间 | 侧重 | 典型组成 |\n|---|---|---|---|\n| 碎片 | 3–5 分钟 | 回忆 | 3–6 道填空/判断/单选/一句话解释 |\n| 主题15 | 约 15 分钟 | 理解 + 回忆 + 少量应用 | 2–3 道回忆、1–2 道解释、1 道小应用 |\n| 深度30 | 约 30 分钟 | 应用、综合、迁移 | 2–4 道综合题，至少 1 道需要推理过程或实现 |\n\n每题标注预计耗时（写在题干末尾，例如\"（约 3 分钟）\"），合计不超过预算。\n\n## 3. 每题必须满足\n- [ ] 明确对应一个主知识点 `kp` 和一个层次 `level`；\n- [ ] 条件充分、无歧义，只有一个合理答案或可清楚定义的可接受答案范围；\n- [ ] 评分标准在出题时同时写入答案文件；\n- [ ] 不能靠题干措辞、选项长度等线索猜出答案；\n- [ ] 选择题干扰项来自真实的常见误解，而不是明显错误；\n- [ ] 应用题使用**新的语境**，不能直接复制笔记原句或原例子；\n- [ ] 外部题目注明出处，答案已核实（`verified: true`），未核实不得用于正式测验。\n\n## 4. 层次与题型建议\n| 层次 | 英语 | 编程 / 计算机课程 |\n|---|---|---|\n| 理解 | 解释句中结构含义、辨析近义表达 | 解释概念原因、比较两个概念 |\n| 回忆 | 填空、补全搭配、写出规则 | 写出定义、步骤、复杂度 |\n| 应用 | 改写、纠错、用目标结构造句、冠词情景选择并说明理由 | 预测代码输出、实现函数、分析场景（如调度、TCP 状态）、变式题 |\n\n英语造句题须说明是否必须使用目标结构；冠词题必须给足语境。\n代码题须写明语言、输入输出、约束和需要处理的边界；需要时给 `starter`。\n\n## 5. 外部高质量习题\n深度30 模式可以引用或改编教材、课程、公开题库题目：\n- 在 `key` 的 `source` 写明出处；\n- 改编时说明改了什么；\n- 不大段照抄受版权保护的内容，优先改编；\n- 无法核实答案的题不用。\n\n## 6. 产出\n1. 练习文件：`练习/<练习ID>.md`，`status: draft`，所有 `answer` 为空。\n2. 答案文件：`练习/答案/<练习ID>-答案.md`。\n3. 将任务请求的 `status` 改为 `done`，在对话中简要说明本次考查重点（不透露答案）。\n", "03-评判规范.md": "---\ntype: ai-rule\norder: 3\n---\n# 评判规范\n\n## 1. 前提\n- 只评判 `status: submitted` 的练习；以 `学习记录/作答快照/` 中对应快照为准。\n- 严格按照答案文件中**作答前已确定**的 `rubric` 给分，不得事后放宽或加严。若发现 rubric 本身有错，新建评判时在 `analysis` 说明，并标 `review: true`。\n\n## 2. 给分原则\n- 按评分点逐项给分，`points` 中逐条写 `+分 理由` / `-分 理由`。\n- 意思正确但措辞不同 → 给分；表达流畅但关键点缺失 → 不给分。\n- 结论正确但推理错误 → 只给结论分；推理正确但计算/笔误 → 扣对应点并标 `粗心`。\n- `unknown: true` 或空白 → `verdict: 未作答`，`score: 0`。\n- `hint_used: true` → `mode: 提示后`。\n- 代码题：检查正确性、边界、复杂度、是否满足题目要求。未实际运行时必须在 `analysis` 写\"静态审阅，未执行测试\"。\n- 英语题：分别看语义、语法、目标结构、自然度；不地道但语法正确的表达，按 rubric 判，并在解析中给出更自然的写法。\n- 无法确定 → `review: true`，说明需要用户或资料确认什么。\n\n## 3. 错误类型（errors 只能使用以下取值）\n| 类型 | 含义 |\n|---|---|\n| 遗忘 | 学过但想不起来 |\n| 未理解 | 概念或规则本身理解有误 |\n| 混淆 | 与另一个知识点混淆（在 analysis 中写明与哪个） |\n| 边界遗漏 | 忽略条件、特殊情况、例外 |\n| 应用失败 | 会说规则但不会在新情境使用 |\n| 表达不准 | 意思接近但关键表述不准确 |\n| 粗心 | 笔误、计算失误 |\n| 题目问题 | 题目本身有歧义或错误（此时 review: true） |\n\n## 4. 错题解析（analysis）必须包含\n1. 你具体错在哪里（引用作答中的关键片段，简短）；\n2. 为什么错（对应错误类型）；\n3. 正确思路或正确过程；\n4. `next`：用什么题、多久后验证是否改正。\n\n## 5. 产出\n1. 新建 `学习记录/评判/G-<练习ID>-A<n>.md`，每题一个 `grade` 块（格式见 01-文件协议）。\n2. 文件末尾写\"本次总结\"：总分、主要问题（最多 3 条）、建议下一步。\n3. 把练习文件 frontmatter `status` 改为 `graded`（这是唯一允许修改练习文件的地方）。\n4. 如有新的稳定规律，更新 `学习状态/学习画像.md`（见 04）。\n5. 提醒用户在插件中执行\"重建学习状态统计\"。\n", "04-学习状态与推荐.md": "---\ntype: ai-rule\norder: 4\n---\n# 学习状态与推荐\n\n## 1. 两份状态文件\n| 文件 | 生成者 | 性质 |\n|---|---|---|\n| `知识状态-自动统计.md` | 插件，按固定算法 | 定量、可复现；AI 只读 |\n| `学习画像.md` | AI | 定性总结；每条结论必须链接到评判记录 |\n\n## 2. 插件算法（供你理解统计含义）\n对每个知识点的每个层次（理解/回忆/应用），收集所有 `review: false` 的 `grade` 块：\n- 单次表现 `r = score / max`\n- 证据权重 `w = 模式权重 × 0.5^(距今天数 / 半衰期)`；模式权重：正式 1.0、提示后 0.5、对话 0.3；半衰期默认 30 天\n- **掌握度** `m = Σ(w·r) / Σw`\n- **证据量** `e = Σw`：< 1 为\"不足\"，1–2.5 为\"一般\"，> 2.5 为\"充分\"\n\n知识点**复习优先级**（越大越该复习）：\n```\n优先级 = 重要度系数 × (0.45×(1 − 最弱层次掌握度) + 0.25×陈旧度 + 0.15×证据不足 + 0.15×近期错误)\n```\n- 重要度系数：importance 1/2/3 → 0.8/1.0/1.2\n- 陈旧度 = min(距最近一次正式验证天数 / 半衰期, 1)\n- 证据不足 = 1 − min(e / 2.5, 1)\n- 近期错误 = 最近 14 天内有错误判定为 1，否则 0\n- 从未测过的知识点：掌握度视为 0、陈旧度 1、证据不足 1，但只在用户请求时引入，避免新内容无限堆积\n\n> 这些数值是复习排序的依据，不是科学意义上的\"记忆概率\"。向用户转述时应说\"统计显示偏弱\"，而不是\"你掌握了 63%\"。\n\n## 3. 学习画像维护\n`学习画像.md` 结构：\n1. 当前学习目标（用户告知的）\n2. 稳定优势（附证据链接）\n3. 薄弱点与错误模式（附证据链接，注明错误类型）\n4. 正在观察的疑似问题（证据不足，需小题验证）\n5. 最近建议与执行情况\n\n规则：\n- 一次错误只能列为\"疑似\"；同类错误 ≥2 次才列为\"薄弱点\"。\n- 对话中的提问只能作为\"疑似\"，需出小题验证。\n- 状态好转要写明，并移出薄弱点。\n\n## 4. 推荐原则\n- 按用户选择的时间预算推荐，**超出预算的候选只列出，不形成\"欠账\"**。\n- 优先：反复错误 > 重要且陈旧 > 证据不足；同一次不要堆满同一个主题，可穿插 1 道相近易混知识点（交错练习）。\n- 掌握度高、证据充分的知识点降低抽查频率；不必每天复习。\n- 理解层掌握度低时先回到解释，不急于出应用题；回忆稳定后再增加应用题。\n", "05-会话流程.md": "---\ntype: ai-rule\norder: 5\n---\n# 会话流程\n\n## 1. 处理插件生成的任务请求\n用户会说\"处理 AI任务/请求-xxx\"。读取请求 frontmatter 的 `task`：\n| task | 动作 |\n|---|---|\n| 出题 | 按 02-出题规范 生成练习与答案文件 |\n| 评判 | 按 03-评判规范 评判指定练习 |\n| 建议 | 读取状态文件，按 04 给出本次复习建议（不生成文件，除非用户要求） |\n完成后把请求 `status` 改为 `done`，并在请求文件末尾追加\"处理结果\"链接。\n\n## 2. 日常答疑（实时对话）\n1. 回答问题前，检查 `学习画像.md` 与 `知识状态-自动统计.md` 中是否有**相关**薄弱点。\n2. 有相关薄弱点时，在回答开头简短提示，例如：\"这和你之前在『二分查找边界』上的错误有关（见 G-...）。\"\n3. 解答后给 1–2 道即时小题，让用户当场作答；即时评判后，若用户同意，写入评判文件，`mode: 对话`。\n4. 不因用户提问就认定其不会，只能记为\"疑似\"。\n\n## 3. 用户直接说\"今天复习 X 分钟\"\n1. 选择模式：≤5 碎片，≈15 主题15，≈30 深度30。\n2. 依据 04 给出建议主题与理由，等用户确认或更换后出题。\n\n## 4. 禁止事项回顾\n- 不改用户作答，不改历史评判，不覆盖笔记正文。\n- 不编造来源与历史表现。\n- 不确定时说明不确定。\n"}, "templates": {"学习画像.md": "---\ntype: profile\nupdated:\n---\n# 学习画像（AI 维护）\n\n> 每条结论都要链接到评判记录。规则见 [[AI规则/04-学习状态与推荐]]。\n\n## 1. 当前学习目标\n\n## 2. 稳定优势\n\n## 3. 薄弱点与错误模式\n\n## 4. 正在观察的疑似问题\n\n## 5. 最近建议与执行情况\n", "示例答案.md": "---\ntype: answer-key\npractice: P-EXAMPLE\n---\n# P-EXAMPLE 参考答案与评分标准\n\n```key\nid: P-EXAMPLE-Q1\ncorrect: B\nrubric:\n  - \"2 选 B\"\nsource: AI原创\nverified: true\n```\n\n```key\nid: P-EXAMPLE-Q2\ncorrect: 错\nrubric:\n  - \"1 判断为错\"\n  - \"1 理由：use 在此为不可数抽象名词，of great use 不加 a\"\nsource: AI原创\nverified: true\n```\n\n```key\nid: P-EXAMPLE-Q3\ncorrect: |\n  of\n  value\nrubric:\n  - \"1 第一空 of\"\n  - \"1 第二空 value\"\nsource: AI原创\nverified: true\n```\n\n```key\nid: P-EXAMPLE-Q4\ncorrect: [A, B, D]\nrubric:\n  - \"2 全对得 2 分；漏选得 1 分；错选得 0 分\"\nsource: AI原创\nverified: true\n```\n\n```key\nid: P-EXAMPLE-Q5\nrubric:\n  - \"1 指出每次比较后需要丢弃一半区间\"\n  - \"1 说明只有有序才能根据比较结果确定目标在哪一侧\"\n  - \"1 表达清晰，无错误推论\"\nsource: AI原创\nverified: true\n```\n\n```key\nid: P-EXAMPLE-Q6\ncorrect: |\n  def first_ge(nums, target):\n      lo, hi = 0, len(nums)\n      while lo < hi:\n          mid = (lo + hi) // 2\n          if nums[mid] < target:\n              lo = mid + 1\n          else:\n              hi = mid\n      return lo\nrubric:\n  - \"2 区间与循环条件正确，不死循环\"\n  - \"2 更新逻辑正确，返回第一个 ≥ target\"\n  - \"1 空数组与全部小于 target 时返回 len(nums)\"\nsource: AI原创\nverified: true\n```\n", "示例练习.md": "---\ntype: practice\nid: P-EXAMPLE\nmode: 主题15\nbudget_min: 15\nkps: [KP-EXAMPLE-EN, KP-EXAMPLE-DS]\nstatus: draft\nattempt: 1\nanswer_key: \"[[练习/答案/P-EXAMPLE-答案]]\"\ncreated: 2026-11-10\n---\n# 示例练习（演示各题型版式）\n\n```quiz\nid: P-EXAMPLE-Q1\ntype: choice\nkp: KP-EXAMPLE-EN\nlevel: 理解\npoints: 2\nprompt: |\n  句子 *This report is of great importance.* 中，`of great importance` 的作用最接近：（约 1 分钟）\noptions:\n  - A. 表示所属关系\n  - B. 相当于形容词 very important，作表语\n  - C. 表示来源\n  - D. 相当于副词修饰 report\nanswer: \"\"\nchecked: []\nunknown: false\nhint_used: false\n```\n\n```quiz\nid: P-EXAMPLE-Q2\ntype: judge\nkp: KP-EXAMPLE-EN\nlevel: 理解\npoints: 2\nprompt: |\n  判断：*The tool is of a great use.* 是正确表达。请说明理由。（约 1 分钟）\nanswer: \"\"\nreason: \"\"\nunknown: false\nhint_used: false\n```\n\n```quiz\nid: P-EXAMPLE-Q3\ntype: fill\nkp: KP-EXAMPLE-EN\nlevel: 回忆\npoints: 2\nblanks: 2\nprompt: |\n  改写：*These suggestions are very valuable.* → These suggestions are ___ great ___.（约 1 分钟）\nanswer: \"\"\nunknown: false\nhint_used: false\nhint: |\n  value 是抽象名词。\n```\n\n```quiz\nid: P-EXAMPLE-Q4\ntype: multi\nkp: KP-EXAMPLE-DS\nlevel: 理解\npoints: 2\nprompt: |\n  关于数组与链表，下列说法正确的是（多选）：（约 2 分钟）\noptions:\n  - A. 数组可以按下标 O(1) 访问\n  - B. 单链表在已知前驱节点时插入为 O(1)\n  - C. 链表按下标访问为 O(1)\n  - D. 数组在头部插入通常为 O(n)\nanswer: \"\"\nchecked: []\nunknown: false\nhint_used: false\n```\n\n```quiz\nid: P-EXAMPLE-Q5\ntype: short\nkp: KP-EXAMPLE-DS\nlevel: 理解\npoints: 3\nprompt: |\n  用自己的话解释：为什么二分查找要求数组有序？（约 3 分钟）\nanswer: \"\"\nunknown: false\nhint_used: false\n```\n\n```quiz\nid: P-EXAMPLE-Q6\ntype: code\nkp: KP-EXAMPLE-DS\nlevel: 应用\npoints: 5\nlang: python\nprompt: |\n  实现 `first_ge(nums, target)`：返回有序数组 nums 中第一个 ≥ target 的下标；若不存在返回 len(nums)。要求 O(log n)，需正确处理空数组。（约 7 分钟）\nstarter: |\n  def first_ge(nums, target):\n      pass\nanswer: \"\"\nunknown: false\nhint_used: false\n```\n", "示例评判.md": "---\ntype: grading\npractice: \"[[练习/P-EXAMPLE]]\"\nattempt: 1\ngraded_at: 2026-11-10\ntotal: 1\nmax: 3\n---\n# 评判 G-P-EXAMPLE-A1（示例）\n\n```grade\nqid: P-EXAMPLE-Q5\nkp: KP-EXAMPLE-DS\nlevel: 理解\nscore: 1\nmax: 3\nmode: 正式\nverdict: 部分正确\nerrors: [表达不准]\npoints:\n  - \"+1 提到每次排除一半\"\n  - \"-1 没有说明有序与判断方向的关系\"\n  - \"-1 将'有序'误说成'无重复'\"\nanalysis: |\n  你说\"二分要求元素不能重复\"，这与有序性无关：有重复元素时，有序数组仍可二分。\n  关键在于：只有有序，比较 nums[mid] 与 target 后才能确定目标在左侧还是右侧。\nnext: |\n  3 天后出一道\"有重复元素的有序数组中找第一个等于 target\"的题验证。\nreview: false\ngraded_at: 2026-11-10\n```\n\n## 本次总结\n- 主要问题：把有序性的作用说成了去重。\n- 建议：主题15 模式复习二分查找的不变量。\n"}};

const VIEW_TYPE = "learning-loop-dashboard";

const DEFAULT_SETTINGS = {
  root: "学习",
  halfLife: 30,
  modeWeights: { 正式: 1.0, 提示后: 0.5, 对话: 0.3 },
  recentErrorDays: 14,
  topN: 15,
};

const LEVELS = ["理解", "回忆", "应用"];
const MODES = {
  碎片: { budget: 5, granularity: ["碎片"], desc: "3–5 分钟，小知识点快速回忆" },
  主题15: { budget: 15, granularity: ["主题", "碎片"], desc: "约 15 分钟，一个主题的理解+回忆+少量应用" },
  深度30: { budget: 30, granularity: ["综合", "主题"], desc: "约 30 分钟，综合/应用/迁移，可引用高质量外部题" },
};
const TYPE_LABEL = { choice: "单选", multi: "多选", judge: "判断", fill: "填空", short: "问答", code: "代码" };

/* ---------------- 工具函数 ---------------- */
const pad = (n) => String(n).padStart(2, "0");
function stamp(d = new Date()) {
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
}
function dateStr(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function timeId(d = new Date()) {
  return `${stamp(d)}-${pad(d.getHours())}${pad(d.getMinutes())}`;
}
function kpId(d = new Date()) {
  return `KP-${stamp(d)}${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}
function daysBetween(a, b) {
  return Math.max(0, (b.getTime() - a.getTime()) / 86400000);
}
function parseDate(v) {
  if (!v) return null;
  const d = new Date(String(v));
  return isNaN(d.getTime()) ? null : d;
}
function safeName(s) {
  return String(s).replace(/[\\/:*?"<>|#^[\]]/g, " ").replace(/\s+/g, " ").trim().slice(0, 60);
}
function safeYaml(src) {
  try { return parseYaml(src) || {}; } catch (e) { return null; }
}
/** 在文本中查找所有指定语言的代码块，返回 {start,end,body} 行号（start 为开栏行） */
function findBlocks(text, lang) {
  const lines = text.split("\n");
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^(\s*)(`{3,}|~{3,})\s*([\w-]+)\s*$/);
    if (m && m[3] === lang) {
      const fence = m[2];
      for (let j = i + 1; j < lines.length; j++) {
        if (lines[j].trim().startsWith(fence) && lines[j].trim().replace(/[`~]/g, "") === "") {
          out.push({ start: i, end: j, body: lines.slice(i + 1, j).join("\n") });
          i = j;
          break;
        }
      }
    }
  }
  return { lines, blocks: out };
}

/* ---------------- 插件主体 ---------------- */
class LearningLoopPlugin extends Plugin {
  async onload() {
    await this.loadSettings();
    this.addSettingTab(new LLSettingTab(this.app, this));

    this.registerView(VIEW_TYPE, (leaf) => new DashboardView(leaf, this));
    this.addRibbonIcon("graduation-cap", "学习面板", () => this.activateView());

    this.registerMarkdownCodeBlockProcessor("quiz", (src, el, ctx) => this.renderQuiz(src, el, ctx));
    this.registerMarkdownCodeBlockProcessor("grade", (src, el, ctx) => this.renderGrade(src, el, ctx));
    this.registerMarkdownCodeBlockProcessor("key", (src, el, ctx) => this.renderKey(src, el, ctx));

    const cmd = (id, name, cb, editor) =>
      this.addCommand(editor ? { id, name, editorCallback: cb } : { id, name, callback: cb });

    cmd("init-vault", "初始化学习库结构与 AI 规则文件", () => this.initVault(false));
    cmd("update-rules", "更新 AI 规则文件（覆盖为插件内置版本）", () => this.initVault(true));
    cmd("open-dashboard", "打开学习面板", () => this.activateView());

    cmd("insert-explain", "为选中内容添加折叠解释", (ed) => this.insertExplain(ed), true);
    cmd("create-kp", "从选中内容创建知识点", (ed, view) => this.createKpFromSelection(ed, view), true);
    cmd("link-kp", "关联已有知识点", (ed) => this.linkKp(ed), true);
    cmd("insert-quiz", "插入题目块", (ed) => this.insertQuizBlock(ed), true);

    cmd("request-practice", "请求 AI 出题（选择复习时长）", () => new ModeModal(this.app, this, null).open());
    cmd("request-practice-note", "基于当前笔记请求 AI 出题", () => {
      const f = this.app.workspace.getActiveFile();
      new ModeModal(this.app, this, f).open();
    });
    cmd("submit-practice", "提交当前练习（锁定作答并生成快照）", () => this.submitPractice());
    cmd("request-grading", "请求 AI 评判当前练习", () => this.requestGrading());
    cmd("request-advice", "请求 AI 学习建议", () => this.requestAdvice());
    cmd("rebuild-stats", "重建学习状态统计与错题本", () => this.rebuildStats(true));
  }

  onunload() {}

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.settings.modeWeights = Object.assign({}, DEFAULT_SETTINGS.modeWeights, this.settings.modeWeights);
  }
  async saveSettings() { await this.saveData(this.settings); }

  p(...parts) { return normalizePath([this.settings.root, ...parts].join("/")); }

  async ensureFolder(path) {
    const segs = normalizePath(path).split("/");
    let cur = "";
    for (const s of segs) {
      cur = cur ? `${cur}/${s}` : s;
      if (!this.app.vault.getAbstractFileByPath(cur)) {
        try { await this.app.vault.createFolder(cur); } catch (e) { /* exists */ }
      }
    }
  }
  async writeFile(path, content, overwrite) {
    path = normalizePath(path);
    const dir = path.split("/").slice(0, -1).join("/");
    if (dir) await this.ensureFolder(dir);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof TFile) {
      if (overwrite) await this.app.vault.modify(f, content);
      return f;
    }
    return await this.app.vault.create(path, content);
  }

  async activateView() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) {
      leaf = this.app.workspace.getRightLeaf(false);
      await leaf.setViewState({ type: VIEW_TYPE, active: true });
    }
    this.app.workspace.revealLeaf(leaf);
  }
  refreshViews() {
    for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
      if (leaf.view && leaf.view.render) leaf.view.render();
    }
  }

  /* ---------- 初始化 ---------- */
  async initVault(overwriteRules) {
    const dirs = ["AI规则", "笔记/英语", "笔记/计算机", "知识点", "练习/答案", "学习记录/评判",
      "学习记录/作答快照", "学习状态", "AI任务", "示例"];
    for (const d of dirs) await this.ensureFolder(this.p(d));
    for (const [name, content] of Object.entries(BUNDLED.rules || {})) {
      await this.writeFile(this.p("AI规则", name), content, overwriteRules);
    }
    const t = BUNDLED.templates || {};
    await this.writeFile(this.p("学习状态", "学习画像.md"), t["学习画像.md"] || "", false);
    await this.writeFile(this.p("示例", "P-EXAMPLE.md"), t["示例练习.md"] || "", false);
    await this.writeFile(this.p("示例", "P-EXAMPLE-答案.md"), t["示例答案.md"] || "", false);
    await this.writeFile(this.p("示例", "G-P-EXAMPLE-A1.md"), t["示例评判.md"] || "", false);
    await this.writeFile(this.p("AI入口.md"), this.entryDoc(), true);
    await this.rebuildStats(false);
    new Notice(overwriteRules ? "AI 规则已更新" : "学习库已初始化");
  }

  entryDoc() {
    const r = this.settings.root;
    return `---
type: ai-entry
---
# AI 入口（给 AI agent 的第一份文件）

学习根目录：\`${r}/\`

1. 先读 [[${r}/AI规则/00-总则]] 与 [[${r}/AI规则/01-文件协议]]。
2. 学习状态：[[${r}/学习状态/知识状态-自动统计]]、[[${r}/学习状态/错题本]]、[[${r}/学习状态/学习画像]]。
3. 待处理任务：\`${r}/AI任务/\` 中 \`status: pending\` 的文件。
4. 题型版式示例：[[${r}/示例/P-EXAMPLE]]、[[${r}/示例/P-EXAMPLE-答案]]、[[${r}/示例/G-P-EXAMPLE-A1]]。
`;
  }

  /* ---------- 笔记辅助 ---------- */
  insertExplain(ed) {
    const sel = ed.getSelection().trim();
    const cur = ed.getCursor("to");
    // 找到当前段落末尾
    let line = cur.line;
    const last = ed.lastLine();
    while (line < last && ed.getLine(line + 1).trim() !== "") line++;
    const title = sel ? sel.replace(/\n/g, " ").slice(0, 50) : "解释";
    const block = `\n\n> [!explain]- ${title}\n> 释义：\n> 用法/结构：\n> 例句：\n> 易错点：\n`;
    const pos = { line, ch: ed.getLine(line).length };
    ed.replaceRange(block, pos);
    ed.setCursor({ line: line + 3, ch: ed.getLine(line + 3).length });
  }

  async createKpFromSelection(ed, view) {
    const sel = ed.getSelection().trim();
    const src = view && view.file ? view.file : null;
    new KpCreateModal(this.app, this, sel, src, async (file, title) => {
      if (sel) ed.replaceSelection(`[[${file.basename}|${sel}]]`);
      else ed.replaceSelection(`[[${file.basename}|${title}]]`);
    }).open();
  }

  getKps() {
    const root = this.p("知识点") + "/";
    return this.app.vault.getMarkdownFiles()
      .filter((f) => f.path.startsWith(root))
      .map((f) => {
        const fm = (this.app.metadataCache.getFileCache(f) || {}).frontmatter || {};
        return { file: f, id: fm.id || f.basename, title: fm.title || f.basename, fm };
      });
  }

  linkKp(ed) {
    const kps = this.getKps();
    if (!kps.length) { new Notice("还没有知识点，可先用“从选中内容创建知识点”"); return; }
    new KpSuggest(this.app, kps, (kp) => {
      const sel = ed.getSelection();
      ed.replaceSelection(`[[${kp.file.basename}|${sel || kp.title}]]`);
    }).open();
  }

  insertQuizBlock(ed) {
    new TypeSuggest(this.app, (type) => {
      const f = this.app.workspace.getActiveFile();
      const fm = f ? ((this.app.metadataCache.getFileCache(f) || {}).frontmatter || {}) : {};
      const base = fm.id || `P-${timeId()}`;
      const n = (ed.getValue().match(/```quiz/g) || []).length + 1;
      const extra = {
        choice: "options:\n  - A. \n  - B. \n  - C. \n  - D. \nchecked: []\n",
        multi: "options:\n  - A. \n  - B. \n  - C. \n  - D. \nchecked: []\n",
        judge: 'reason: ""\n',
        fill: "blanks: 1\n",
        short: "",
        code: "lang: python\nstarter: |\n  \n",
      }[type];
      ed.replaceSelection(
        "```quiz\n" +
        `id: ${base}-Q${n}\ntype: ${type}\nkp: \nlevel: 回忆\npoints: 2\nprompt: |\n  \n${extra}` +
        'answer: ""\nunknown: false\nhint_used: false\n```\n'
      );
    }).open();
  }

  /* ---------- 题目渲染 ---------- */
  practiceStatus(sourcePath) {
    const f = this.app.vault.getAbstractFileByPath(sourcePath);
    if (!(f instanceof TFile)) return "draft";
    const fm = (this.app.metadataCache.getFileCache(f) || {}).frontmatter || {};
    return fm.status || "draft";
  }

  async renderMd(md, el, sourcePath) {
    const R = obsidian.MarkdownRenderer;
    if (R.render) await R.render(this.app, md, el, sourcePath, this);
    else await R.renderMarkdown(md, el, sourcePath, this);
  }

  async renderQuiz(src, el, ctx) {
    const q = safeYaml(src);
    el.addClass("ll-quiz");
    if (!q) { el.createDiv({ cls: "ll-error", text: "题目 YAML 格式错误，请检查缩进。" }); return; }
    const status = this.practiceStatus(ctx.sourcePath);
    const locked = status !== "draft";
    const type = q.type || "short";

    const head = el.createDiv({ cls: "ll-quiz-head" });
    head.createSpan({ cls: "ll-tag ll-type", text: TYPE_LABEL[type] || type });
    if (q.level) head.createSpan({ cls: `ll-tag ll-level ll-level-${q.level}`, text: q.level });
    if (q.points != null) head.createSpan({ cls: "ll-tag", text: `${q.points} 分` });
    head.createSpan({ cls: "ll-qid", text: q.id || "" });
    if (locked) head.createSpan({ cls: "ll-tag ll-locked", text: status === "graded" ? "已评判" : "已提交" });

    const body = el.createDiv({ cls: "ll-prompt" });
    await this.renderMd(String(q.prompt || ""), body, ctx.sourcePath);

    const state = {
      answer: q.answer == null ? "" : String(q.answer),
      checked: Array.isArray(q.checked) ? q.checked.slice() : [],
      reason: q.reason == null ? "" : String(q.reason),
      unknown: !!q.unknown,
      hint_used: !!q.hint_used,
    };
    const letter = (opt, i) => {
      const m = String(opt).match(/^\s*([A-Za-z])[.、．)]/);
      return m ? m[1].toUpperCase() : String.fromCharCode(65 + i);
    };
    const area = el.createDiv({ cls: "ll-answer" });
    const opts = Array.isArray(q.options) ? q.options : [];

    if (type === "choice" || type === "multi") {
      opts.forEach((opt, i) => {
        const L = letter(opt, i);
        const row = area.createEl("label", { cls: "ll-option" });
        const inp = row.createEl("input", { type: type === "choice" ? "radio" : "checkbox" });
        inp.name = `${q.id}-opt`;
        inp.checked = state.checked.includes(L);
        inp.disabled = locked;
        row.createSpan({ text: String(opt) });
        inp.addEventListener("change", () => {
          if (type === "choice") state.checked = inp.checked ? [L] : [];
          else {
            state.checked = state.checked.filter((x) => x !== L);
            if (inp.checked) state.checked.push(L);
            state.checked.sort();
          }
          state.answer = state.checked.join(",");
          markDirty();
        });
      });
    } else if (type === "judge") {
      const row = area.createDiv({ cls: "ll-judge" });
      for (const v of ["对", "错"]) {
        const lab = row.createEl("label", { cls: "ll-option ll-inline" });
        const inp = lab.createEl("input", { type: "radio" });
        inp.name = `${q.id}-judge`;
        inp.checked = state.answer === v;
        inp.disabled = locked;
        lab.createSpan({ text: v });
        inp.addEventListener("change", () => { if (inp.checked) { state.answer = v; markDirty(); } });
      }
      const ta = area.createEl("textarea", { cls: "ll-text", attr: { rows: "2", placeholder: "理由" } });
      ta.value = state.reason; ta.disabled = locked;
      ta.addEventListener("input", () => { state.reason = ta.value; markDirty(); });
    } else if (type === "fill") {
      const n = Math.max(1, parseInt(q.blanks || 1, 10));
      const vals = state.answer.split("\n");
      const inputs = [];
      for (let i = 0; i < n; i++) {
        const row = area.createDiv({ cls: "ll-fill-row" });
        row.createSpan({ cls: "ll-fill-no", text: `空 ${i + 1}` });
        const inp = row.createEl("input", { type: "text", cls: "ll-fill" });
        inp.value = vals[i] || ""; inp.disabled = locked;
        inputs.push(inp);
        inp.addEventListener("input", () => { state.answer = inputs.map((x) => x.value).join("\n"); markDirty(); });
      }
    } else {
      const isCode = type === "code";
      if (isCode && q.lang) area.createDiv({ cls: "ll-lang", text: q.lang });
      const ta = area.createEl("textarea", {
        cls: isCode ? "ll-text ll-code" : "ll-text",
        attr: { rows: isCode ? "12" : "5", spellcheck: "false", placeholder: isCode ? "在此写代码" : "在此作答" },
      });
      ta.value = state.answer || (isCode && q.starter ? String(q.starter) : "");
      if (isCode && !state.answer && q.starter) state.answer = String(q.starter);
      ta.disabled = locked;
      ta.addEventListener("input", () => { state.answer = ta.value; markDirty(); });
      if (isCode) {
        ta.addEventListener("keydown", (e) => {
          if (e.key === "Tab") {
            e.preventDefault();
            const s = ta.selectionStart, en = ta.selectionEnd;
            ta.value = ta.value.slice(0, s) + "    " + ta.value.slice(en);
            ta.selectionStart = ta.selectionEnd = s + 4;
            state.answer = ta.value; markDirty();
          }
        });
      }
    }

    if (q.hint) {
      const det = el.createEl("details", { cls: "ll-hint" });
      det.createEl("summary", { text: "提示（展开会记为“提示后”）" });
      const hb = det.createDiv();
      await this.renderMd(String(q.hint), hb, ctx.sourcePath);
      det.addEventListener("toggle", () => {
        if (det.open && !state.hint_used && !locked) { state.hint_used = true; hintBox.checked = true; markDirty(); }
      });
    }

    const bar = el.createDiv({ cls: "ll-bar" });
    const unkLab = bar.createEl("label", { cls: "ll-inline" });
    const unkBox = unkLab.createEl("input", { type: "checkbox" });
    unkBox.checked = state.unknown; unkBox.disabled = locked;
    unkLab.createSpan({ text: "不会" });
    unkBox.addEventListener("change", () => { state.unknown = unkBox.checked; markDirty(); });

    const hintLab = bar.createEl("label", { cls: "ll-inline" });
    const hintBox = hintLab.createEl("input", { type: "checkbox" });
    hintBox.checked = state.hint_used; hintBox.disabled = locked;
    hintLab.createSpan({ text: "用了提示/查看了笔记" });
    hintBox.addEventListener("change", () => { state.hint_used = hintBox.checked; markDirty(); });

    const saveBtn = bar.createEl("button", { text: "保存作答", cls: "ll-save" });
    const msg = bar.createSpan({ cls: "ll-msg" });
    if (locked) { saveBtn.disabled = true; msg.setText("已锁定"); }
    let timer = null;
    const markDirty = () => {
      msg.setText("未保存");
      if (timer) window.clearTimeout(timer);
      timer = window.setTimeout(() => save(), 1500); // 停止输入 1.5 秒后自动保存
    };
    const save = async () => {
      if (locked) return;
      if (timer) { window.clearTimeout(timer); timer = null; }
      const ok = await this.writeQuizAnswer(ctx.sourcePath, q.id, state);
      msg.setText(ok ? "已保存" : "保存失败：找不到题目 id");
    };
    saveBtn.addEventListener("click", save);
  }

  /** 按题目 id 定位 quiz 块，只更新作答字段 */
  async writeQuizAnswer(path, id, state) {
    const f = this.app.vault.getAbstractFileByPath(path);
    if (!(f instanceof TFile) || !id) return false;
    let ok = false;
    await this.app.vault.process(f, (text) => {
      const { lines, blocks } = findBlocks(text, "quiz");
      for (const b of blocks) {
        const obj = safeYaml(b.body);
        if (!obj || obj.id !== id) continue;
        obj.answer = state.answer;
        if ("checked" in obj || state.checked.length) obj.checked = state.checked;
        if (obj.type === "judge") obj.reason = state.reason;
        obj.unknown = state.unknown;
        obj.hint_used = state.hint_used;
        const yaml = stringifyYaml(obj).replace(/\n$/, "");
        lines.splice(b.start + 1, b.end - b.start - 1, ...yaml.split("\n"));
        ok = true;
        return lines.join("\n");
      }
      return text;
    });
    return ok;
  }

  async renderGrade(src, el, ctx) {
    const g = safeYaml(src);
    el.addClass("ll-grade");
    if (!g) { el.createDiv({ cls: "ll-error", text: "评判 YAML 格式错误" }); return; }
    const ratio = g.max ? Number(g.score) / Number(g.max) : 0;
    el.addClass(ratio >= 0.999 ? "ll-good" : ratio >= 0.5 ? "ll-mid" : "ll-bad");
    const head = el.createDiv({ cls: "ll-quiz-head" });
    head.createSpan({ cls: "ll-score", text: `${g.score ?? "?"} / ${g.max ?? "?"}` });
    if (g.verdict) head.createSpan({ cls: "ll-tag", text: g.verdict });
    if (g.level) head.createSpan({ cls: `ll-tag ll-level ll-level-${g.level}`, text: g.level });
    if (g.mode && g.mode !== "正式") head.createSpan({ cls: "ll-tag", text: g.mode });
    if (g.review) head.createSpan({ cls: "ll-tag ll-review", text: "待复核" });
    head.createSpan({ cls: "ll-qid", text: g.qid || "" });
    const errs = Array.isArray(g.errors) ? g.errors : (g.errors ? [g.errors] : []);
    if (errs.length) {
      const e = el.createDiv({ cls: "ll-errors" });
      errs.forEach((x) => e.createSpan({ cls: "ll-tag ll-err", text: x }));
    }
    if (Array.isArray(g.points) && g.points.length) {
      const ul = el.createEl("ul", { cls: "ll-points" });
      g.points.forEach((p) => {
        const s = String(p);
        ul.createEl("li", { text: s, cls: s.trim().startsWith("-") ? "ll-minus" : "ll-plus" });
      });
    }
    for (const [k, label] of [["analysis", "错因与解析"], ["next", "下一步"]]) {
      if (!g[k]) continue;
      const det = el.createEl("details", { cls: "ll-detail" });
      if (k === "analysis" && ratio < 0.999) det.open = true;
      det.createEl("summary", { text: label });
      await this.renderMd(String(g[k]), det.createDiv(), ctx.sourcePath);
    }
  }

  async renderKey(src, el, ctx) {
    const k = safeYaml(src);
    el.addClass("ll-key");
    if (!k) { el.createDiv({ cls: "ll-error", text: "答案 YAML 格式错误" }); return; }
    const det = el.createEl("details");
    det.createEl("summary", { text: `参考答案 ${k.id || ""}（点击展开）` });
    const box = det.createDiv();
    let md = "";
    if (k.correct != null) {
      const c = Array.isArray(k.correct) ? k.correct.join(", ") : String(k.correct);
      md += c.includes("\n") ? "**答案**\n```\n" + c + "\n```\n" : `**答案**：${c}\n\n`;
    }
    if (Array.isArray(k.rubric)) md += "**评分点**\n" + k.rubric.map((r) => `- ${r}`).join("\n") + "\n\n";
    if (k.source) md += `来源：${k.source}${k.verified === false ? "（未核实）" : ""}\n`;
    await this.renderMd(md, box, ctx.sourcePath);
  }

  /* ---------- 练习流程 ---------- */
  activePractice() {
    const f = this.app.workspace.getActiveFile();
    if (!f) { new Notice("请先打开练习文件"); return null; }
    const fm = (this.app.metadataCache.getFileCache(f) || {}).frontmatter || {};
    if (fm.type !== "practice") { new Notice("当前文件不是练习文件（frontmatter type: practice）"); return null; }
    return { f, fm };
  }

  async submitPractice() {
    const a = this.activePractice(); if (!a) return;
    const { f, fm } = a;
    if (fm.status && fm.status !== "draft") { new Notice(`该练习状态为 ${fm.status}，无需重复提交`); return; }
    const text = await this.app.vault.read(f);
    const { blocks } = findBlocks(text, "quiz");
    const empty = blocks.map((b) => safeYaml(b.body) || {})
      .filter((q) => !q.unknown && !String(q.answer || "").trim()).length;
    const go = async () => {
      const now = new Date();
      await this.app.fileManager.processFrontMatter(f, (m) => {
        m.status = "submitted";
        m.submitted_at = `${dateStr(now)} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
      });
      const snap = await this.app.vault.read(f);
      const att = fm.attempt || 1;
      await this.writeFile(this.p("学习记录/作答快照", `${fm.id || f.basename}-A${att}.md`), snap, true);
      new Notice("已提交并生成作答快照");
      await this.requestGrading(f);
      this.refreshViews();
    };
    if (empty) new ConfirmModal(this.app, `还有 ${empty} 题未作答也未标记“不会”，仍要提交吗？`, go).open();
    else await go();
  }

  async requestGrading(file) {
    let f = file, fm;
    if (!f) { const a = this.activePractice(); if (!a) return; f = a.f; fm = a.fm; }
    else fm = (this.app.metadataCache.getFileCache(f) || {}).frontmatter || {};
    if (!file && fm.status === "draft") { new Notice("请先提交练习"); return; }
    const id = fm.id || f.basename;
    const att = fm.attempt || 1;
    const r = this.settings.root;
    const content = `---
type: request
task: 评判
status: pending
created: ${dateStr()}
practice: "[[${f.path.replace(/\.md$/, "")}]]"
attempt: ${att}
---
# 请求：评判 ${id}

请按 [[${r}/AI规则/03-评判规范]] 评判：

- 练习：[[${f.path.replace(/\.md$/, "")}]]
- 作答快照：[[${r}/学习记录/作答快照/${id}-A${att}]]
- 答案与评分标准：${fm.answer_key || "（见练习 frontmatter answer_key）"}
- 输出：\`${r}/学习记录/评判/G-${id}-A${att}.md\`
- 完成后：练习 status 改为 graded；本请求 status 改为 done；必要时更新学习画像。
`;
    const out = await this.writeFile(this.p("AI任务", `请求-评判-${id}-A${att}.md`), content, true);
    new Notice(`已生成评判请求：${out.basename}。在 agent 中说“处理 ${out.path}”即可。`);
    this.refreshViews();
  }

  async requestPractice(mode, topic, noteFile, kpIds) {
    const cfg = MODES[mode];
    const stats = await this.computeStats();
    const r = this.settings.root;
    let cands = stats.rows.filter((x) => x.tested && cfg.granularity.includes(x.granularity || "主题"));
    if (topic) cands = cands.filter((x) => `${x.title} ${x.subject} ${x.domain}`.includes(topic));
    cands = cands.sort((a, b) => b.priority - a.priority).slice(0, mode === "碎片" ? 8 : 5);
    const chosen = (kpIds || []).map((id) => stats.rows.find((x) => x.id === id)).filter(Boolean);
    const id = `P-${timeId()}`;
    const fmt = (x) => `| [[${x.file.basename}|${x.title}]] | ${x.id} | ${x.weakestLevel || "-"} | ${x.priority.toFixed(2)} | ${x.lastErrorTypes.join("、") || "-"} |`;
    const content = `---
type: request
task: 出题
status: pending
created: ${dateStr()}
mode: ${mode}
budget_min: ${cfg.budget}
practice_id: ${id}
topic: "${(topic || "").replace(/"/g, "'")}"
---
# 请求：出题（${mode}，约 ${cfg.budget} 分钟）

请按 [[${r}/AI规则/02-出题规范]] 出题。

- 模式说明：${cfg.desc}
- 练习 ID：\`${id}\`
- 输出：\`${r}/练习/${id}.md\` 与 \`${r}/练习/答案/${id}-答案.md\`
- 主题/范围：${topic || "未指定（按学习状态推荐）"}
${noteFile ? `- 依据笔记：[[${noteFile.path.replace(/\.md$/, "")}]]` : ""}
${chosen.length ? "\n## 用户指定的知识点\n" + chosen.map((x) => `- [[${x.file.basename}|${x.title}]] (${x.id})`).join("\n") : ""}

## 统计建议优先覆盖（插件按算法排序，仅供参考）
${cands.length ? "| 知识点 | ID | 最弱层次 | 优先级 | 近期错误类型 |\n|---|---|---|---|---|\n" + cands.map(fmt).join("\n") : "暂无测验记录。"}

## 参考
- [[${r}/学习状态/知识状态-自动统计]]
- [[${r}/学习状态/错题本]]
- [[${r}/学习状态/学习画像]]
`;
    const out = await this.writeFile(this.p("AI任务", `请求-出题-${id}.md`), content, true);
    new Notice(`已生成出题请求：${out.basename}`);
    await this.app.workspace.getLeaf(false).openFile(out);
    this.refreshViews();
  }

  async requestAdvice() {
    await this.rebuildStats(false);
    const r = this.settings.root;
    const d = dateStr();
    const content = `---
type: request
task: 建议
status: pending
created: ${d}
---
# 请求：学习建议

请按 [[${r}/AI规则/04-学习状态与推荐]]，阅读：
- [[${r}/学习状态/知识状态-自动统计]]
- [[${r}/学习状态/错题本]]
- [[${r}/学习状态/学习画像]]

给出：碎片 / 主题15 / 深度30 三种时长下各自推荐复习的内容与理由；超出预算的只列为候选。
`;
    const out = await this.writeFile(this.p("AI任务", `请求-建议-${timeId()}.md`), content, true);
    new Notice(`已生成建议请求：${out.basename}`);
    this.refreshViews();
  }

  /* ---------- 统计算法 ---------- */
  async collectGrades() {
    const root = this.p("学习记录/评判") + "/";
    const out = [];
    for (const f of this.app.vault.getMarkdownFiles().filter((x) => x.path.startsWith(root))) {
      const text = await this.app.vault.cachedRead(f);
      const fm = (this.app.metadataCache.getFileCache(f) || {}).frontmatter || {};
      for (const b of findBlocks(text, "grade").blocks) {
        const g = safeYaml(b.body);
        if (!g || !g.kp) continue;
        g._file = f;
        g._date = parseDate(g.graded_at) || parseDate(fm.graded_at) || new Date(f.stat.mtime);
        out.push(g);
      }
    }
    return out;
  }

  async computeStats() {
    const S = this.settings, now = new Date();
    const kps = this.getKps();
    const byId = new Map(kps.map((k) => [String(k.id), k]));
    const grades = await this.collectGrades();
    const valid = grades.filter((g) => !g.review && Number(g.max) > 0);
    const pending = grades.filter((g) => g.review);
    const groups = new Map();
    for (const g of valid) {
      const k = String(g.kp);
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(g);
    }
    const rows = [];
    const allIds = new Set([...byId.keys(), ...groups.keys()]);
    for (const id of allIds) {
      const kp = byId.get(id);
      const gs = groups.get(id) || [];
      const fm = kp ? kp.fm : {};
      const lv = {};
      for (const L of LEVELS) {
        let sw = 0, swr = 0, n = 0;
        for (const g of gs.filter((x) => (x.level || "回忆") === L)) {
          const r = Math.max(0, Math.min(1, Number(g.score) / Number(g.max)));
          const mw = S.modeWeights[g.mode || "正式"] ?? 1;
          const w = mw * Math.pow(0.5, daysBetween(g._date, now) / S.halfLife);
          sw += w; swr += w * r; n++;
        }
        lv[L] = { m: sw > 0 ? swr / sw : null, e: sw, n };
      }
      const tested = LEVELS.filter((L) => lv[L].n > 0);
      let weakestLevel = null, weakM = 1;
      for (const L of tested) if (lv[L].m < weakM || weakestLevel === null) { weakM = lv[L].m; weakestLevel = L; }
      if (!tested.length) weakM = 0;
      const formal = gs.filter((g) => (g.mode || "正式") === "正式").map((g) => g._date);
      const lastFormal = formal.length ? new Date(Math.max(...formal.map((d) => d.getTime()))) : null;
      const last = gs.length ? new Date(Math.max(...gs.map((g) => g._date.getTime()))) : null;
      const stale = lastFormal ? Math.min(daysBetween(lastFormal, now) / S.halfLife, 1) : 1;
      const eTotal = tested.length ? Math.min(...tested.map((L) => lv[L].e)) : 0;
      const lowEv = 1 - Math.min(eTotal / 2.5, 1);
      const recentErrs = gs.filter((g) => daysBetween(g._date, now) <= S.recentErrorDays && Number(g.score) < Number(g.max));
      const recentErr = recentErrs.length ? 1 : 0;
      const imp = { 1: 0.8, 2: 1.0, 3: 1.2 }[Number(fm.importance) || 2] || 1.0;
      const priority = imp * (0.45 * (1 - weakM) + 0.25 * stale + 0.15 * lowEv + 0.15 * recentErr);
      const errTypes = {};
      gs.filter((g) => Number(g.score) < Number(g.max)).forEach((g) => {
        (Array.isArray(g.errors) ? g.errors : g.errors ? [g.errors] : []).forEach((e) => { errTypes[e] = (errTypes[e] || 0) + 1; });
      });
      rows.push({
        id, kp, file: kp ? kp.file : { basename: id }, title: kp ? kp.title : `${id}（无知识点文件）`,
        domain: fm.domain || "", subject: fm.subject || "", granularity: fm.granularity || "主题",
        importance: Number(fm.importance) || 2, lv, tested: tested.length > 0, weakestLevel,
        weakM, eTotal, lastFormal, last, priority, recentErr,
        errTypes, lastErrorTypes: Object.keys(errTypes).sort((a, b) => errTypes[b] - errTypes[a]).slice(0, 3),
        wrongCount: gs.filter((g) => Number(g.score) < Number(g.max)).length,
      });
    }
    return { rows, grades: valid, pending, now };
  }

  async rebuildStats(notify) {
    const st = await this.computeStats();
    const r = this.settings.root;
    const pct = (x) => (x == null ? "—" : `${Math.round(x * 100)}%`);
    const ev = (e) => (e < 1 ? "不足" : e <= 2.5 ? "一般" : "充分");
    const lvCell = (o) => (o.n ? `${pct(o.m)}·${ev(o.e)}(${o.n})` : "—");
    const tested = st.rows.filter((x) => x.tested).sort((a, b) => b.priority - a.priority);
    const untested = st.rows.filter((x) => !x.tested);
    const link = (x) => (x.kp ? `[[${x.file.basename}\\|${x.title}]]` : x.title);

    let md = `---
type: stats
generated: ${dateStr(st.now)}
half_life: ${this.settings.halfLife}
---
# 知识状态（插件自动统计，请勿手改）

> 算法见 [[${r}/AI规则/04-学习状态与推荐]]。格式：掌握度·证据量(次数)。掌握度为加权得分率，用于排序，不是记忆概率。
> 有效评判 ${st.grades.length} 条；待复核 ${st.pending.length} 条（不计入）。已测知识点 ${tested.length} 个，未测 ${untested.length} 个。

## 复习优先级（前 ${this.settings.topN}）
| # | 知识点 | 领域 | 粒度 | 理解 | 回忆 | 应用 | 最弱 | 最近正式验证 | 近期错误 | 优先级 |
|---|---|---|---|---|---|---|---|---|---|---|
`;
    tested.slice(0, this.settings.topN).forEach((x, i) => {
      md += `| ${i + 1} | ${link(x)} | ${x.domain}/${x.subject} | ${x.granularity} | ${lvCell(x.lv["理解"])} | ${lvCell(x.lv["回忆"])} | ${lvCell(x.lv["应用"])} | ${x.weakestLevel || "—"} | ${x.lastFormal ? dateStr(x.lastFormal) : "—"} | ${x.lastErrorTypes.join("、") || "—"} | ${x.priority.toFixed(2)} |\n`;
    });

    const byDomain = {};
    tested.forEach((x) => { const k = x.domain || "未分类"; (byDomain[k] = byDomain[k] || []).push(x); });
    md += `\n## 全部已测知识点（按领域）\n`;
    for (const [d, xs] of Object.entries(byDomain)) {
      md += `\n### ${d}\n| 知识点 | 科目 | 理解 | 回忆 | 应用 | 错误次数 | 优先级 |\n|---|---|---|---|---|---|---|\n`;
      xs.forEach((x) => {
        md += `| ${link(x)} | ${x.subject} | ${lvCell(x.lv["理解"])} | ${lvCell(x.lv["回忆"])} | ${lvCell(x.lv["应用"])} | ${x.wrongCount} | ${x.priority.toFixed(2)} |\n`;
      });
    }
    const errAgg = {};
    tested.forEach((x) => Object.entries(x.errTypes).forEach(([k, v]) => { errAgg[k] = (errAgg[k] || 0) + v; }));
    md += `\n## 错误类型分布\n`;
    md += Object.keys(errAgg).length
      ? Object.entries(errAgg).sort((a, b) => b[1] - a[1]).map(([k, v]) => `- ${k}：${v}`).join("\n") + "\n"
      : "暂无。\n";
    md += `\n## 未测知识点（${untested.length}）\n`;
    md += untested.length ? untested.map((x) => `- ${link(x).replace("\\|", "|")}（${x.granularity}，重要度 ${x.importance}）`).join("\n") + "\n" : "无。\n";
    if (st.pending.length) {
      md += `\n## 待复核评判\n` + st.pending.map((g) => `- ${g.qid || ""} → [[${g._file.basename}]]`).join("\n") + "\n";
    }
    await this.writeFile(this.p("学习状态", "知识状态-自动统计.md"), md, true);

    // 错题本
    const wrong = st.grades.filter((g) => Number(g.score) < Number(g.max))
      .sort((a, b) => b._date - a._date);
    const kpTitle = (id) => { const x = st.rows.find((r) => r.id === String(id)); return x ? x.title : id; };
    let wm = `---
type: mistakes
generated: ${dateStr(st.now)}
---
# 错题本（插件自动生成，请勿手改）

共 ${wrong.length} 条（不含待复核）。按知识点分组，组内最新在前。
`;
    const groups = {};
    wrong.forEach((g) => { (groups[g.kp] = groups[g.kp] || []).push(g); });
    for (const [k, gs] of Object.entries(groups)) {
      wm += `\n## ${kpTitle(k)}（${k}）\n`;
      gs.forEach((g) => {
        const errs = (Array.isArray(g.errors) ? g.errors : g.errors ? [g.errors] : []).join("、") || "—";
        const brief = String(g.analysis || "").split("\n").find((l) => l.trim()) || "";
        wm += `- ${dateStr(g._date)} · ${g.level || ""} · ${g.score}/${g.max} · ${errs} · [[${g._file.basename}]] ${g.qid || ""}\n`;
        if (brief) wm += `  - ${brief.slice(0, 120)}\n`;
      });
    }
    await this.writeFile(this.p("学习状态", "错题本.md"), wm, true);
    if (notify) new Notice("学习状态与错题本已更新");
    this.refreshViews();
    return st;
  }

  async listByType(folder, type) {
    const root = this.p(folder) + "/";
    return this.app.vault.getMarkdownFiles().filter((f) => f.path.startsWith(root)).map((f) => ({
      f, fm: (this.app.metadataCache.getFileCache(f) || {}).frontmatter || {},
    })).filter((x) => !type || x.fm.type === type);
  }
}

/* ---------------- 面板 ---------------- */
class DashboardView extends ItemView {
  constructor(leaf, plugin) { super(leaf); this.plugin = plugin; }
  getViewType() { return VIEW_TYPE; }
  getDisplayText() { return "学习面板"; }
  getIcon() { return "graduation-cap"; }
  async onOpen() { await this.render(); }

  async render() {
    const P = this.plugin, el = this.contentEl;
    el.empty(); el.addClass("ll-dash");
    el.createEl("h3", { text: "开始复习" });
    const modes = el.createDiv({ cls: "ll-modes" });
    for (const [m, cfg] of Object.entries(MODES)) {
      const b = modes.createEl("button", { cls: "ll-mode-btn" });
      b.createDiv({ cls: "ll-mode-name", text: m });
      b.createDiv({ cls: "ll-mode-desc", text: cfg.desc });
      b.addEventListener("click", () => new ModeModal(this.app, P, null, m).open());
    }
    const tools = el.createDiv({ cls: "ll-tools" });
    const tb = (t, fn) => tools.createEl("button", { text: t }).addEventListener("click", fn);
    tb("请求学习建议", () => P.requestAdvice());
    tb("重建统计", () => P.rebuildStats(true));
    tb("AI 入口", () => this.open(P.p("AI入口.md")));

    let st;
    try { st = await P.computeStats(); } catch (e) { el.createDiv({ text: "统计失败：" + e.message }); return; }

    el.createEl("h3", { text: "优先复习" });
    const top = st.rows.filter((x) => x.tested).sort((a, b) => b.priority - a.priority).slice(0, 8);
    if (!top.length) el.createDiv({ cls: "ll-muted", text: "暂无评判记录。先请求出题并完成一次练习。" });
    const ul = el.createEl("ul", { cls: "ll-list" });
    top.forEach((x) => {
      const li = ul.createEl("li");
      const a = li.createEl("a", { text: x.title });
      a.addEventListener("click", () => x.kp && this.app.workspace.getLeaf(false).openFile(x.file));
      li.createSpan({ cls: "ll-muted", text: ` · 最弱 ${x.weakestLevel || "—"} · ${x.lastErrorTypes.join("、") || "无近期错误"}` });
    });

    const practices = await P.listByType("练习", "practice");
    const drafts = practices.filter((x) => (x.fm.status || "draft") === "draft");
    const subm = practices.filter((x) => x.fm.status === "submitted");
    const reqs = (await P.listByType("AI任务", "request")).filter((x) => x.fm.status === "pending");
    const section = (title, items, label) => {
      el.createEl("h3", { text: `${title}（${items.length}）` });
      const u = el.createEl("ul", { cls: "ll-list" });
      items.slice(0, 10).forEach((x) => {
        const li = u.createEl("li");
        const a = li.createEl("a", { text: label(x) });
        a.addEventListener("click", () => this.app.workspace.getLeaf(false).openFile(x.f));
      });
    };
    section("待作答练习", drafts, (x) => `${x.fm.id || x.f.basename} · ${x.fm.mode || ""}`);
    section("已提交待评判", subm, (x) => x.fm.id || x.f.basename);
    section("待 AI 处理的请求", reqs, (x) => `${x.fm.task || ""} · ${x.f.basename}`);
    if (st.pending.length) el.createDiv({ cls: "ll-muted", text: `待复核评判 ${st.pending.length} 条，见知识状态文件。` });
  }
  open(path) {
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof TFile) this.app.workspace.getLeaf(false).openFile(f);
    else new Notice("文件不存在，请先运行“初始化学习库”");
  }
}

/* ---------------- 弹窗 ---------------- */
class ModeModal extends Modal {
  constructor(app, plugin, noteFile, mode) {
    super(app); this.plugin = plugin; this.noteFile = noteFile; this.mode = mode || "主题15"; this.topic = ""; this.kps = [];
  }
  onOpen() {
    const c = this.contentEl;
    c.createEl("h3", { text: "请求 AI 出题" });
    new Setting(c).setName("复习时长").addDropdown((d) => {
      Object.entries(MODES).forEach(([k, v]) => d.addOption(k, `${k}（${v.budget} 分钟）`));
      d.setValue(this.mode).onChange((v) => (this.mode = v));
    });
    new Setting(c).setName("主题/范围").setDesc("可留空，由统计与 AI 推荐；例如：冠词、二分查找、TCP")
      .addText((t) => t.onChange((v) => (this.topic = v.trim())));
    if (this.noteFile) c.createDiv({ cls: "ll-muted", text: `依据笔记：${this.noteFile.basename}` });
    const kpBox = c.createDiv({ cls: "ll-muted" });
    new Setting(c).setName("指定知识点（可选）").addButton((b) => b.setButtonText("添加").onClick(() => {
      new KpSuggest(this.app, this.plugin.getKps(), (kp) => {
        this.kps.push(kp.id); kpBox.setText("已选：" + this.kps.join(", "));
      }).open();
    }));
    new Setting(c).addButton((b) => b.setButtonText("生成请求").setCta().onClick(async () => {
      this.close();
      await this.plugin.requestPractice(this.mode, this.topic, this.noteFile, this.kps);
    }));
  }
  onClose() { this.contentEl.empty(); }
}

class KpCreateModal extends Modal {
  constructor(app, plugin, sel, src, done) {
    super(app); this.plugin = plugin; this.src = src; this.done = done;
    this.v = { title: sel.split("\n")[0].slice(0, 60), domain: "英语", subject: "", granularity: "碎片", importance: "2" };
    this.sel = sel;
  }
  onOpen() {
    const c = this.contentEl, v = this.v;
    c.createEl("h3", { text: "创建知识点" });
    new Setting(c).setName("标题").addText((t) => t.setValue(v.title).onChange((x) => (v.title = x)));
    new Setting(c).setName("领域").addDropdown((d) => d.addOptions({ 英语: "英语", 编程: "编程" }).setValue(v.domain).onChange((x) => (v.domain = x)));
    new Setting(c).setName("科目").setDesc("词汇/语法/冠词/句型 或 Python/数据结构/操作系统/计算机组成/计算机网络/C/Java/Rust")
      .addText((t) => t.onChange((x) => (v.subject = x)));
    new Setting(c).setName("粒度").setDesc("碎片=随时小复习；主题=15分钟；综合=30分钟深度")
      .addDropdown((d) => d.addOptions({ 碎片: "碎片", 主题: "主题", 综合: "综合" }).setValue(v.granularity).onChange((x) => (v.granularity = x)));
    new Setting(c).setName("重要度").addDropdown((d) => d.addOptions({ 1: "1 低", 2: "2 中", 3: "3 高" }).setValue(v.importance).onChange((x) => (v.importance = x)));
    new Setting(c).addButton((b) => b.setButtonText("创建").setCta().onClick(async () => {
      if (!v.title.trim()) { new Notice("标题不能为空"); return; }
      const id = kpId();
      const fm = { type: "kp", id, title: v.title.trim(), domain: v.domain, subject: v.subject, granularity: v.granularity,
        importance: Number(v.importance), related: [], source: this.src ? `[[${this.src.path.replace(/\.md$/, "")}]]` : "", created: dateStr() };
      const body = `---\n${stringifyYaml(fm)}---\n# ${v.title.trim()}\n\n${this.sel ? "> " + this.sel.replace(/\n/g, "\n> ") + "\n\n" : ""}## 解释\n\n## 例子\n\n## 边界与反例\n\n## 易错点\n`;
      const name = `${safeName(v.title)} ${id.slice(-6)}.md`;
      const f = await this.plugin.writeFile(this.plugin.p("知识点", name), body, false);
      this.close();
      await this.done(f, v.title.trim());
      new Notice(`已创建知识点 ${id}`);
    }));
  }
  onClose() { this.contentEl.empty(); }
}

class ConfirmModal extends Modal {
  constructor(app, msg, ok) { super(app); this.msg = msg; this.ok = ok; }
  onOpen() {
    this.contentEl.createEl("p", { text: this.msg });
    new Setting(this.contentEl)
      .addButton((b) => b.setButtonText("取消").onClick(() => this.close()))
      .addButton((b) => b.setButtonText("确定").setCta().onClick(async () => { this.close(); await this.ok(); }));
  }
  onClose() { this.contentEl.empty(); }
}

class KpSuggest extends FuzzySuggestModal {
  constructor(app, kps, pick) { super(app); this.kps = kps; this.pick = pick; this.setPlaceholder("搜索知识点"); }
  getItems() { return this.kps; }
  getItemText(k) { return `${k.title}  ${k.fm.domain || ""}/${k.fm.subject || ""}  ${k.id}`; }
  onChooseItem(k) { this.pick(k); }
}
class TypeSuggest extends FuzzySuggestModal {
  constructor(app, pick) { super(app); this.pick = pick; this.setPlaceholder("选择题型"); }
  getItems() { return Object.keys(TYPE_LABEL); }
  getItemText(t) { return `${TYPE_LABEL[t]} (${t})`; }
  onChooseItem(t) { this.pick(t); }
}

/* ---------------- 设置 ---------------- */
class LLSettingTab extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }
  display() {
    const c = this.containerEl, P = this.plugin, S = P.settings;
    c.empty();
    c.createEl("h2", { text: "Learning Loop 设置" });
    new Setting(c).setName("学习根目录").setDesc("修改后请重新运行“初始化学习库”")
      .addText((t) => t.setValue(S.root).onChange(async (v) => { S.root = v.trim() || "学习"; await P.saveSettings(); }));
    new Setting(c).setName("证据半衰期（天）").setDesc("越久以前的表现权重越低")
      .addText((t) => t.setValue(String(S.halfLife)).onChange(async (v) => { const n = Number(v); if (n > 0) { S.halfLife = n; await P.saveSettings(); } }));
    for (const k of Object.keys(DEFAULT_SETTINGS.modeWeights)) {
      new Setting(c).setName(`模式权重：${k}`)
        .addText((t) => t.setValue(String(S.modeWeights[k])).onChange(async (v) => { const n = Number(v); if (n >= 0) { S.modeWeights[k] = n; await P.saveSettings(); } }));
    }
    new Setting(c).setName("近期错误窗口（天）")
      .addText((t) => t.setValue(String(S.recentErrorDays)).onChange(async (v) => { const n = Number(v); if (n > 0) { S.recentErrorDays = n; await P.saveSettings(); } }));
    new Setting(c).setName("优先级表显示条数")
      .addText((t) => t.setValue(String(S.topN)).onChange(async (v) => { const n = parseInt(v, 10); if (n > 0) { S.topN = n; await P.saveSettings(); } }));
    c.createEl("p", { cls: "ll-muted", text: "修改算法参数后，请同步修改 AI规则/04-学习状态与推荐.md 中的说明，保证 AI 理解一致。" });
  }
}

module.exports = LearningLoopPlugin;
module.exports._test = { findBlocks, MODES };
